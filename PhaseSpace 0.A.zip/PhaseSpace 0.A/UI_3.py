#!/usr/bin/env python
# -*- coding: cp1252 -*-
#------------------------------------------------
#-3 variables user interface for Phase Space 0.A-
#--------Programado por Anton Ferre Pujol--------
#------------------------------------------------
#---------compatible with python 2 and 3---------

import matplotlib
matplotlib.use('TkAgg')
from numpy import sin, cos, tan, exp, linspace, meshgrid, hypot, zeros, log
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from scipy.integrate import odeint
from sys import version_info
if version_info[0] < 3:
    from Tkinter import Tk, Canvas, Label, Button, Menu, Entry 
    import Tkinter as Tk
    from tkColorChooser import askcolor
else:
    from tkinter import Tk, Canvas, Label, Button, Menu, Entry
    import tkinter as Tk
    from tkinter.colorchooser import askcolor
import time
import metodos as Me
#variables

version="0.A"
screen_res="1200x600"
language_sel=""
pantalla_completa=True
label_list_2D=["y=m(x):","x=m(y)"]
label_list_3D=[]
menu_list=[]
#-----globals-----
color_curva_1,color_curva_2, color_fase, color_punto="#800040","#800040","#0080FF","#FF8000"
color_X, color_Y, color_Z="#0000FF","#00FF00","#FF0000"
color_fondo="#EEEEEE"
ventana=""
ventana_x=1210
ventana_y=600
x_min,x_max,x_n=0.,10.,10.
y_min,y_max,y_n=0.,10.,10.
z_min,z_max,z_n=0.,10.,10.
t_min,t_max,t_n=0.,10.,100.
x0,y0,z0=0,0,0
f,g,h,m,n="","","","",""
fun_f,fun_g,fun_h=0,0,0
X,X1,XF=[],[],[]
Y,Y1=[],[]
Z,Z1=[],[]

texto_t_min,texto_t_max,texto_t_n,texto_t0=0,0,0,0
texto_x_min,texto_x_max,texto_x0,texto_f,texto_mx=0,0,0,0,0
texto_y_min,texto_y_max,texto_y0,texto_g,texto_my=0,0,0,0,0
texto_z_min,texto_z_max,texto_z0,texto_h,texto_mz=0,0,0,0,0
texto_px,texto_py,texto_pz=0,0,0
L_F_fx_fy,L_F_sistema="",""
label_t_n,label_f,label_g,label_x0,label_y0,label_t0="","","","","",""
label_t_min,label_t_max,label_mx,label_my="","","",""
canvas_2D=0
metodo_integracion=""
ultima_accion=[]
Q1=[]
es_implicita=False
implicita=""

#-----Main UI-----
class interfaz_basica(Tk.Frame):
    def __init__(self,parent):
        self.parent=parent
        self.init_UI_2D()
    #-----Common commands-----
    def _quit(self):
        self.parent.quit()     
        self.parent.destroy()
    def on_key_event(self,event):
        pass
    
    def _configuracion(self):
        global screen_res, language, pantalla_completa,color_fondo,version
        global color_curva_1,color_curva_2, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        ventana_conf=Tk.Toplevel()
        ventana_conf.geometry("300x280")
        ventana_conf.wm_title("PhaseSpace "+chr(223)+version+" Config.")
        ventana_conf.iconbitmap("icono.ico")
        ventana_conf.configure(background=color_fondo)
        #label_conf_screen_res=Tk.Label(master=ventana_conf,text="Screen res.")
        #label_conf_screen_res.place(x=10,y=10)
        #label_conf_full_screen=Tk.Label(master=ventana_conf,text="Full screen")
        #label_conf_full_screen.place(x=10,y=40)

        #resol_pantalla=Tk.StringVar(ventana_conf)
        #resol_pantalla.set("1210x600")
        #lista_resolucion=Tk.OptionMenu(ventana_conf,resol_pantalla,"1210x600","800x600","1024x768","1280x768","1280x720")
        #lista_resolucion.place(x=120, y=5)
        
        label_conf_bck_color=Tk.Label(master=ventana_conf,text="Background color")
        label_conf_bck_color.place(x=10,y=40)
        button_conf_bck=Tk.Button(master=ventana_conf,text="  ",background=color_fondo, command=lambda: _color(color_fondo))
        button_conf_bck.place(x=120, y=35)
        label_conf_phase=Tk.Label(master=ventana_conf,text="Phase line color")
        label_conf_phase.place(x=10,y=70)
        button_conf_phase_color=Tk.Button(master=ventana_conf,text="  ",background=color_fase, command=lambda: _color(color_fase))
        button_conf_phase_color.place(x=120, y=65)
        label_conf_point=Tk.Label(master=ventana_conf,text="Critical point color")
        label_conf_point.place(x=10,y=100)
        button_conf_point=Tk.Button(master=ventana_conf,text="  ",background=color_punto, command=lambda: _color(color_punto))
        button_conf_point.place(x=120, y=95)
        #label_conf_curve_1=Tk.Label(master=ventana_conf,text="Slope zero curve color")
        #label_conf_curve_1.place(x=10,y=160)
        #button_conf_curve_1=Tk.Button(master=ventana_conf,text="  ",background=color_curva_1, command=lambda: _color(color_curva_1))
        #button_conf_curve_1.place(x=120, y=155)

        label_conf_curve_2=Tk.Label(master=ventana_conf,text="Line color")
        label_conf_curve_2.place(x=10,y=130)
        button_conf_curve_2=Tk.Button(master=ventana_conf,text="  ",background=color_curva_2, command=lambda: _color(color_curva_2))
        button_conf_curve_2.place(x=120, y=125)
        
        label_conf_X_color=Tk.Label(master=ventana_conf,text="X(t) color")
        label_conf_X_color.place(x=10,y=160)
        button_conf_X=Tk.Button(master=ventana_conf,text="  ",background=color_X, command=lambda: _color(color_X))
        button_conf_X.place(x=120, y=155)
        label_conf_Y_color=Tk.Label(master=ventana_conf,text="Y(t) color")
        label_conf_Y_color.place(x=10,y=190)
        button_conf_Y=Tk.Button(master=ventana_conf,text="  ",background=color_Y, command=lambda: _color(color_Y))
        button_conf_Y.place(x=120, y=185)
        label_conf_Z_color=Tk.Label(master=ventana_conf,text="Z(t) color")
        label_conf_Z_color.place(x=10,y=220)
        button_conf_Z=Tk.Button(master=ventana_conf,text="  ",background=color_Z, command=lambda: _color(color_Z))
        button_conf_Z.place(x=120, y=215)
        #boton_conf_ok=Tk.Button(master=ventana_conf, text="Ok")
        #boton_conf_ok.place(x=10, y=325)
        #boton_conf_aplicar=Tk.Button(master=ventana_conf,text="Aply")
        #boton_conf_aplicar.place(x=50, y=325)

        def _color(variable):
            global color_curva, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
            color_e = askcolor()[1]
            if variable == color_fondo:
                color_fondo=color_e
                return color_fondo
                button_conf_bck.configure(background = color_e)
                self.configure(background = color_e)
                button_conf_bck.place(x=120, y=65)
                
            elif variable == color_fase:
                color_fase= color_e
                return color_fase
                button_conf_phase.configure(background = color_e)
            elif variable == color_punto:
                color_punto= color_e
                return color_punto
                button_conf_point.configure(background = color_e)
            elif variable == color_curva_1:
                color_punto= color_e
                return color_curva_1
                button_conf_curve_1.configure(background = color_e)
            elif variable == color_color_curva_2:
                color_punto= color_e
                return color_curva_2
                button_conf_curve_2.configure(background = color_e)
            elif variable == color_X:
                color_X= color_e
                return color_X
                button_X.configure(background = color_e)
            elif variable == color_Y:
                color_Y= color_e
                return color_Y
                button_Y.configure(background = color_e)
            elif variable == color_Z:
                color_Z= color_e
                return color_Z
                button_Z.configure(background = color_e)
            ventana_conf.update()
            self.update()

            

    def _idioma():
        pass
    
    
        
        
    #-----Loads UI-----
    def init_UI_basica(self):
        global color_curva_1, color_curva_2, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        global texto_x0,texto_y0,texto_x_min,texto_x_max,texto_y_min,texto_y_max,texto_ny,texto_t0
        global texto_t_min,texto_t_max,texto_t_n,texto_f,texto_g,texto_mx,texto_my,canvas,metodo_integracion
        global L_F_fx_fy,L_F_sistema, color_curva, es_implicita
        global label_t_n,label_f,label_g,label_x0,label_y0,label_t_min,label_t_max,label_mx,label_my,label_t0
        global texto_h,texto_z0,texto_z_min,texto_z_max,texto_px,texto_py,texto_pz,texto_mz
        label_names=["Axis:","x min:","x max:", "y min:", "y max:","System","f=dx/dt:","g=dy/dt:",
                    "x0:","y0:","t0:","n:","t min:","t max:", "Integration method:","Implicit curve"]
        menu_names=["New project","Save data","Load data","Exit","File","Undo","Delete data","Delete graph",
                    "Edition","Phase space","Vector field","Solutions","Critical Points",
                    "Horizontal and vertical slope curves","Draw","Set axes","Colors","Config.","Configuration",
                    "Help","About","Help"]
        #-----images and window config-----
        imagen_ejes=Tk.PhotoImage(file="./iconos/ejes.gif")
        imagen_fases=Tk.PhotoImage(file="./iconos/fases.gif")
        imagen_vector=Tk.PhotoImage(file="./iconos/vector.gif")
        imagen_soluciones=Tk.PhotoImage(file="./iconos/soluciones.gif")
        imagen_borra_f=Tk.PhotoImage(file="./iconos/borra_f.gif")
        imagen_borra_d=Tk.PhotoImage(file="./iconos/borra_d.gif")
        imagen_undo=Tk.PhotoImage(file="./iconos/undo.gif")
        imagen_puntos=Tk.PhotoImage(file="./iconos/puntos.gif")
        imagen_curvas=Tk.PhotoImage(file="./iconos/curvas.gif")
        imagen_color=Tk.PhotoImage(file="./iconos/color.gif")
        imagen_implicita=Tk.PhotoImage(file="./iconos/implicita.gif")
        imagen_color=Tk.PhotoImage(file="./iconos/color.gif")
        self.parent.wm_title("PhaseSpace "+chr(223)+version)
        self.parent.geometry(screen_res)
        self.parent.configure(background=color_fondo)
        self.parent.iconbitmap("icono.ico")
        #-----Menu bar-----
        barra_menu=Tk.Menu(self.parent)
        self.parent.configure(menu=barra_menu)
        archivo_menu=Tk.Menu(barra_menu)
        archivo_menu.add_command(label=menu_names[0])
        archivo_menu.add_command(label=menu_names[1])
        archivo_menu.add_command(label=menu_names[2])
        archivo_menu.add_command(label=menu_names[3],command=self._quit)
        barra_menu.add_cascade(label=menu_names[4], menu=archivo_menu)
        edicion_menu=Tk.Menu(barra_menu)
        edicion_menu.add_command(label=menu_names[5],command=self._undo)
        edicion_menu.add_command(label=menu_names[6],command=self._borra_datos_3)
        edicion_menu.add_command(label=menu_names[7],command=self._borra_grafica)
        barra_menu.add_cascade(label=menu_names[8], menu=edicion_menu)
        dibuja_menu=Tk.Menu(barra_menu)
        dibuja_menu.add_command(label=menu_names[9],command=self._fases)
        dibuja_menu.add_command(label=menu_names[10],command=self._vectorial)
        dibuja_menu.add_command(label=menu_names[11],command=self._Xt_Yt)
        dibuja_menu.add_command(label=menu_names[12],command=self._punto_c)
        dibuja_menu.add_command(label=menu_names[13],command=self._pendiente)
        barra_menu.add_cascade(label=menu_names[14], menu=dibuja_menu)
        configuracion_menu=Tk.Menu(barra_menu)
        configuracion_menu.add_command(label=menu_names[15],command=self._ejes)
        configuracion_menu.add_command(label=menu_names[16],command=self._configuracion)
        configuracion_menu.add_command(label=menu_names[17],command=self._configuracion)
        barra_menu.add_cascade(label=menu_names[18], menu=configuracion_menu)
        ayuda_menu=Tk.Menu(barra_menu)
        ayuda_menu.add_command(label=menu_names[19])
        ayuda_menu.add_command(label=menu_names[20])
        ayuda_menu.add_cascade(label=menu_names[21],menu=ayuda_menu)
        #-----Buttons-----
        button_ejes = Tk.Button(master=self.parent, text='Ejes', image=imagen_ejes,command=self._ejes, width=32,height=32)
        button_ejes.image=imagen_ejes
        button_ejes.place(x=10,y=10)
        button_Vectorial = Tk.Button(master=self.parent, text='C. Vectorial', image =imagen_vector, command=self._vectorial,width=32,height=32)
        button_Vectorial.image=imagen_vector
        button_Vectorial.place(x=50,y=10)
        button_Fases = Tk.Button(master=self.parent, text='Mapa de Fases', image=imagen_fases,command=self._fases,width=32,height=32)
        button_Fases.image=imagen_fases
        button_Fases.place(x=90,y=10)
        button_Pcritico = Tk.Button(master=self.parent, text='P. Critico', image=imagen_puntos,command=self._punto_c, width=32,height=32)
        button_Pcritico.image=imagen_puntos
        button_Pcritico.place(x=130,y=10)
        button_PendienteC = Tk.Button(master=self.parent, text='Pendiente', image=imagen_curvas,command=self._pendiente,  width=32,height=32)
        button_PendienteC.image=imagen_curvas
        button_PendienteC.place(x=170,y=10)
        button_Implicita = Tk.Button(master=self.parent, text='implicita', image=imagen_implicita,command=self._implicita, width=32, height=32)
        button_Implicita.image=imagen_implicita
        button_Implicita.place(x=210,y=10)
        button_Soluciones=Tk.Button(master=self.parent, text='f(t)', image=imagen_soluciones,command=self._Xt_Yt,  width=32,height=32)
        button_Soluciones.image=imagen_soluciones
        button_Soluciones.place(x=250,y=10)
        button_Deshacer = Tk.Button(master=self.parent, text='Undo', image=imagen_undo,command=self._undo, width=32,height=32)
        button_Deshacer.image=imagen_undo
        button_Deshacer.place(x=290,y=10)
        button_Borrar_D = Tk.Button(master=self.parent, text='Borrar Datos', image=imagen_borra_d, command=self._borra_datos_3,width=32,height=32)
        button_Borrar_D.image=imagen_borra_d
        button_Borrar_D.place(x=330,y=10)
        button_Borrar_G = Tk.Button(master=self.parent, text='Borrar Grafica', image=imagen_borra_f,command=self._borra_grafica_3, width=32,height=32)
        button_Borrar_G.image=imagen_borra_f
        button_Borrar_G.place(x=370,y=10)
        button_Color = Tk.Button(master=self.parent, text='Color', image=imagen_color,command=self._borra_grafica, width=32,height=32)
        button_Color.image=imagen_color
        button_Color.place(x=410,y=10)
        #-----Labels and text entries of Axis-----
        L_F_fx_fy=Tk.LabelFrame(master=self.parent,text=label_names[0],width=245,height=110)
        L_F_fx_fy.configure(background=color_fondo)
        L_F_fx_fy.place(x=10,y=80)

        label_x_min=Tk.Label(master=self.parent,text=label_names[1], font=("Helvetica",9),width=6)
        label_x_min.configure(background=color_fondo)
        label_x_min.place(x=20, y=105)
        texto_x_min=Tk.Entry(master=self.parent,width=9)
        texto_x_min.place(x=70,y=105)
        label_x_max=Tk.Label(master=self.parent,text=label_names[2],font=("Helvetica",9), width=6)
        label_x_max.configure(background=color_fondo)
        label_x_max.place(x=135, y=105)
        texto_x_max=Tk.Entry(master=self.parent,width=9)
        texto_x_max.place(x=185,y=105)
        label_y_min=Tk.Label(master=self.parent,text=label_names[3],font=("Helvetica",9), width=6)
        label_y_min.configure(background=color_fondo)
        label_y_min.place(x=20, y=130)
        texto_y_min=Tk.Entry(master=self.parent,width=9)
        texto_y_min.place(x=70,y=130)
        label_y_max=Tk.Label(master=self.parent,text=label_names[4],font=("Helvetica",9), width=6)
        label_y_max.configure(background=color_fondo)
        label_y_max.place(x=135, y=130)
        texto_y_max=Tk.Entry(master=self.parent,width=9)
        texto_y_max.place(x=185,y=130)
        label_z_min=Tk.Label(master=self.parent,text='z min:',font=("Helvetica",9), width=6)
        label_z_min.place(x=20, y=155)
        texto_z_min=Tk.Entry(master=self.parent,width=9)
        texto_z_min.place(x=70,y=155)
        label_z_max=Tk.Label(master=self.parent,text='z max:',font=("Helvetica",9), width=6)
        label_z_max.place(x=135, y=155)
        texto_z_max=Tk.Entry(master=self.parent,width=9)
        texto_z_max.place(x=185,y=155)
        #----System entries and initial conditions----
        L_F_sistema=Tk.LabelFrame(master=self.parent,text=label_names[5],font=("Helvetica",9),width=595,height=230)
        L_F_sistema.configure(background=color_fondo)
        L_F_sistema.place(x=10,y=200)
        label_f=Tk.Label(master=self.parent,text=label_names[6], font=("Helvetica",9),width=6)
        label_f.configure(background=color_fondo)
        label_f.place(x=20, y=225)
        texto_f=Tk.Entry(master=self.parent,font=("Helvetica",9),width=74)
        texto_f.place(x=70,y=225)
        label_g=Tk.Label(master=self.parent,text=label_names[7], font=("Helvetica",9),width=6)
        label_g.configure(background=color_fondo)
        label_g.place(x=20, y=250)
        texto_g=Tk.Entry(master=self.parent,font=("Helvetica",9),width=74)
        texto_g.place(x=70,y=250)
        label_h=Tk.Label(master=self.parent,text="h=dz/dt", font=("Helvetica",9),width=6)
        label_h.place(x=20, y=275)
        texto_h=Tk.Entry(master=self.parent,font=("Helvetica",9),width=74)
        texto_h.place(x=70,y=275)

        label_x0=Tk.Label(master=self.parent,text=label_names[8], font=("Helvetica",9),width=6)
        label_x0.configure(background=color_fondo)
        label_x0.place(x=20, y=300)
        texto_x0=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_x0.place(x=70,y=300)
        label_y0=Tk.Label(master=self.parent,text=label_names[9],font=("Helvetica",9), width=6)
        label_y0.configure(background=color_fondo)
        label_y0.place(x=135, y=300)
        texto_y0=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_y0.place(x=185,y=300)
        label_z0=Tk.Label(master=self.parent,text='z 0:',font=("Helvetica",9), width=6)
        label_z0.place(x=250, y=300)
        texto_z0=Tk.Entry(master=self.parent,width=9)
        texto_z0.place(x=300,y=300)

        label_t0=Tk.Label(master=self.parent,text=label_names[10],font=("Helvetica",9),width=6)
        label_t0.configure(background=color_fondo)
        label_t0.place(x=250,y=325)
        texto_t0=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_t0.place(x=300,y=325)
        label_t_n=Tk.Label(master=self.parent,text=label_names[11], font=("Helvetica",9),width=6)
        label_t_n.configure(background=color_fondo)
        label_t_n.place(x=365, y=300)
        texto_t_n=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_t_n.place(x=415,y=300)
        label_t_min=Tk.Label(master=self.parent,text=label_names[12], font=("Helvetica",9),width=6)
        label_t_min.configure(background=color_fondo)
        label_t_min.place(x=20, y=325)
        texto_t_min=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_t_min.place(x=70,y=325)
        label_t_max=Tk.Label(master=self.parent,text=label_names[13],font=("Helvetica",9), width=6)
        label_t_max.configure(background=color_fondo)
        label_t_max.place(x=135, y=325)
        texto_t_max=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_t_max.place(x=185,y=325)
        #----Curves of infinite and zero ----
        label_mx=Tk.Label(master=self.parent,text='x=m(y,z):', font=("Helvetica",9),width=6)
        label_mx.configure(background=color_fondo)
        label_mx.place(x=20, y=350)
        texto_mx=Tk.Entry(master=self.parent,font=("Helvetica",9),width=41)
        texto_mx.place(x=70,y=350)
        label_my=Tk.Label(master=self.parent,text='y=m(x,z):',font=("Helvetica",9), width=6)
        label_my.configure(background=color_fondo)
        label_my.place(x=20, y=375)
        texto_my=Tk.Entry(master=self.parent,font=("Helvetica",9),width=41)
        texto_my.place(x=70,y=375)
        label_mz=Tk.Label(master=self.parent,text='z=m(x,y)',font=("Helvetica",9), width=6)
        label_mz.place(x=20, y=400)
        texto_mz=Tk.Entry(master=self.parent,font=("Helvetica",9),width=41)
        texto_mz.place(x=70,y=400)

        #----List of numerical methods-----
        L_F_metodo=Tk.LabelFrame(master=self.parent,text=label_names[14],font=("Helvetica",9),width=200,height=70)
        L_F_metodo.configure(background=color_fondo)
        L_F_metodo.place(x=260,y=80)
        metodo_integracion=Tk.StringVar(self.parent)
        metodo_integracion.set("Runge Kutta 4")
        lista_metodos=Tk.OptionMenu(self.parent,metodo_integracion,"Heun","Runge Kutta 4","Lsoda","Euler I")
        lista_metodos.place(x=270, y=105)
        boton_implicita=Tk.Button(master=self.parent,text="implicit", command=self._implicita)
        boton_implicita.place(x=365,y=325)
        label_log=Tk.Label(master=self.parent,text="Log:",font=("Helvetica",9), width=6)
        label_log.place(x=20,y=425)
        frame_log=Tk.Frame(master=self.parent)
        texto_log=Tk.Text(master=frame_log,width=70,height=5)
        barra_log=Tk.Scrollbar(master=frame_log)
        texto_log.configure(yscrollcommand=barra_log.set)
        barra_log.config(command=texto_log.yview)
        frame_log.place(x=20,y=450)
        texto_log.pack(side=Tk.LEFT)
        barra_log.pack(side=Tk.RIGHT, fill=Tk.Y)

        #----Planes----
        L_F_plane=Tk.LabelFrame(master=self.parent,text="Planos",font=("Helvetica",9),width=140,height=110)
        L_F_plane.configure(background=color_fondo)
        L_F_plane.place(x=465,y=80)
        label_px=Tk.Label(master=self.parent,text='x:',font=("Helvetica",9), width=6)
        label_px.place(x=485, y=105)
        texto_px=Tk.Entry(master=self.parent,width=8)
        texto_px.place(x=535,y=105)
        label_py=Tk.Label(master=self.parent,text='y:',font=("Helvetica",9), width=6)
        label_py.place(x=485, y=130)
        texto_py=Tk.Entry(master=self.parent,width=8)
        texto_py.place(x=535,y=130)
        label_pz=Tk.Label(master=self.parent,text='z',font=("Helvetica",9), width=6)
        label_pz.place(x=485, y=155)
        texto_pz=Tk.Entry(master=self.parent,width=8)
        texto_pz.place(x=535,y=155)


#-----3 variable UI-----
class interfaz_3D(interfaz_basica):
    def __init__(self,parent):
        self.parent=parent
        self.init_UI_basica()
        self.init_UI_3D()
        self.figure=Figure(figsize=(5.8,5.3), dpi=100)
        self.figure.subplots_adjust(bottom=0.1,right=0.95,top=0.9, left=0.1)
        self.a_3d=self.figure.add_subplot(221, projection="3d")
        self.axy=self.figure.add_subplot(222)
        self.ayz=self.figure.add_subplot(223)
        self.axz=self.figure.add_subplot(224)
        self.canvas=self.init_canvas()
        self._borra_datos_3()
    def init_UI_3D(self):
        pass        

    def init_canvas(self):
        canvas_3D = FigureCanvasTkAgg(self.figure, master=self.parent)
        canvas_3D.show()
        canvas_3D.get_tk_widget().pack(side=Tk.TOP, fill=Tk.BOTH, expand=1)
        toolbar = NavigationToolbar2TkAgg( canvas_3D, self.parent )
        toolbar.update()
        canvas_3D._tkcanvas.place(x=610,y=10)
        canvas_3D.mpl_connect('key_press_event', self.on_key_event)
        canvas_3D.mpl_connect('button_press_event', self.on_click)
        return canvas_3D
        
    def _importa_metodos(self):#Place
        pass
    def _borra_datos_3(self):
        global texto_x0,texto_y0,texto_x_min,texto_x_max,texto_y_min,texto_y_max,texto_ny,texto_t0
        global texto_t_min,texto_t_max,texto_t_n,texto_f,texto_g,texto_mx,texto_my,texto_mz
        global texto_h,texto_z0,texto_z_min,texto_z_max,texto_px,texto_py,texto_pz,texto_h
        texto_t_min.delete(0,'end')
        texto_t_max.delete(0,'end')
        texto_t_n.delete(0,'end')
        texto_t0.delete(0,'end')
        texto_t_min.insert(0,-10)
        texto_t_max.insert(0,10)
        texto_t_n.insert(0,1000)
        texto_t0.insert(0,0)
        texto_x_min.delete(0,'end')
        texto_x_max.delete(0,'end')
        texto_x0.delete(0,'end')
        texto_x_min.insert(0,-5)
        texto_x_max.insert(0,5)
        texto_x0.insert(0,0)
        texto_y_min.delete(0,'end')
        texto_y_max.delete(0,'end')
        texto_y0.delete(0,'end')
        texto_y_min.insert(0,-4)
        texto_y_max.insert(0,4)
        texto_y0.insert(0,0)
        texto_z_min.delete(0,'end')
        texto_z_max.delete(0,'end')
        texto_z0.delete(0,'end')
        texto_z_min.insert(0,-4)
        texto_z_max.insert(0,4)
        texto_z0.insert(0,0)
        texto_f.delete(0,'end')
        texto_g.delete(0,'end')
        texto_f.insert(0,"")
        texto_g.insert(0,"")
        texto_h.delete(0,"end")
        texto_h.insert(0,"")
        texto_mx.delete(0,'end')
        texto_mx.insert(0,"")
        texto_my.delete(0,'end')
        texto_my.insert(0,"")
        texto_mz.delete(0,'end')
        texto_mz.insert(0,"")
        texto_px.delete(0,'end')
        texto_px.insert(0,0)
        texto_py.delete(0,'end')
        texto_py.insert(0,0)
        texto_pz.delete(0,'end')
        texto_pz.insert(0,0)
        self._ejes()
    def _borra_grafica_3(self):
        self.a_3d.cla()
        self.axy.cla()
        self.ayz.cla()
        self.axz.cla()
        self._ejes()
        self.canvas.show()
    def _ejes(self):
        global x_min, x_max, y_min, y_max,z_min,z_max
        x_min=float(texto_x_min.get())
        x_max=float(texto_x_max.get())
        y_min=float(texto_y_min.get())
        y_max=float(texto_y_max.get())
        z_min=float(texto_z_min.get())
        z_max=float(texto_z_max.get())
        self.axy.set_xlim([x_min,x_max])
        self.axy.set_ylim([y_min,y_max])
        self.ayz.set_xlim([y_min,y_max])
        self.ayz.set_ylim([z_min,z_max])
        self.axz.set_xlim([x_min,x_max])
        self.axz.set_ylim([z_min,z_max])
        self.a_3d.set_xlim([x_min,x_max])
        self.a_3d.set_ylim([y_min,y_max])
        self.a_3d.set_zlim([z_min,z_max])
        self.canvas.show()
    
    def OK_3(self):
        global t_min,t_max,t_n,x0,y0,z0,f,g,h,x_n,y_n,z_n,metodo_integracion,t0,mx,my,mz
        global texto_h,texto_y,texto_x
        self._ejes()
        t_min=float(texto_t_min.get())
        t_max=float(texto_t_max.get())
        t_n=float(texto_t_n.get())
        x0=float(texto_x0.get())
        y0=float(texto_y0.get())
        t0=float(texto_t0.get())
        z0=float(texto_z0.get())
        f=texto_f.get()
        g=texto_g.get()
        h=texto_h.get()
        print(h)
        mx=texto_mx.get()
        my=texto_my.get()
        mz=texto_mz.get()
    def on_click(self,event):#placeholder, not finished
        global x0,y0,ultima_accion,Q1
        global canvas_2D
        boton_mouse=event.button
        if boton_mouse==1:
            px=float(texto_px.get())
            py=float(texto_py.get())
            pz=float(texto_pz.get())
            #find subplot
            sb=0 #placeholder
            if sb==222:
                texto_x0.delete(0,'end')
                texto_x0.insert(0,event.xdata)
                texto_y0.delete(0,'end')
                texto_y0.insert(0,event.ydata)
                texto_z0.delete(0,'end')
                texto_z0.insert(0,pz)
            elif sb==223:
                texto_x0.delete(0,'end')
                texto_x0.insert(0,px)
                texto_y0.delete(0,'end')
                texto_y0.insert(0,event.xdata)
                texto_z0.delete(0,'end')
                texto_z0.insert(0,event.ydata)
            elif sb==224:
                texto_x0.delete(0,'end')
                texto_x0.insert(0,event.xdata)
                texto_y0.delete(0,'end')
                texto_y0.insert(0,py)
                texto_z0.delete(0,'end')
                texto_z0.insert(0,event.ydata)
            
            #self._fases()
            
        if boton_mouse==3:
            pass
    def _on_move(self,event):
        pass
    def _button_press(self,event):
        pass
    def _button_release(self,event):
        pass
    def _borra_grafica(self):#placeholder
        pass

    def _fases(self):#not finished
        global f,g,h,X,Y,Z,X1,Y1,Z1,t_min,t_max,t_n,t0
        self.OK_3()
        X.append(x0)
        Y.append(y0)
        Z.append(z0)
        
        metodo=metodo_integracion.get()

        #if f!="" and g!="" and h!=0:
        if metodo=="Runge Kutta 4":
            if t_min==0:
                X,Y,Z=Me.RK4_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,0,t_max,t_n)     
            
            else:
                X1.append(x0)
                Y1.append(y0)
                Z1.append(z0)
                X,Y,Z=Me.RK4_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,t0,t_max,t_n)
                X1A,Y1A,Z1A=Me.RK4_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,t0,t_min,t_n)
            
        elif metodo=="Heun":
            if t_min==0:
                X,Y,Z=Me.Heun_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,0,t_max,t_n)     
            
            else:
                X1.append(x0)
                Y1.append(y0)
                Z1.append(z0)
                X,Y,Z=Me.Heun_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,t0,t_max,t_n)
                X1A,Y1A,Z1A=Me.Heun_3D(f,g,h,Me._f_3D,Me._g_3D,Me._h_3D,x0,y0,z0,t0,t_min,t_n)
        elif metodo=="Lsoda":
            pass
        if t_min==0:
            print('t_min=0')
            XT=X
            YT=Y
            ZT=Z
        else:
            X1=list(reversed(X1A))
            Y1=list(reversed(Y1A))
            Z1=list(reversed(Z1A))
            XT=X1+X
            YT=Y1+Y
            ZT=Z1+Z
            
        self.axy.plot(XT,YT,lw=0.2,color=color_fase)
        self.axy.set_xlabel('x(t)')
        self.axy.set_ylabel('y(t)')
        self.axy.grid(True)
        self.ayz.plot(YT,ZT,lw=0.2,color=color_fase)
        self.ayz.set_xlabel('y(t)')
        self.ayz.set_ylabel('z(t)')
        self.ayz.grid(True)
        self.axz.plot(XT,ZT,lw=0.2,color=color_fase)
        self.axz.set_xlabel('x(t)')
        self.axz.set_ylabel('z(t)')
        self.axz.grid(True)
        self.a_3d.plot(XT,YT,ZT,lw=0.2,c=color_fase)        
        self.canvas.show()
        #X,Y,Z=[],[],[]
        #X1,Y1,Z1=[],[],[]
        XT,YT,ZT=[],[],[]


    def funcion_p(self,X):
        global f,g,h
        h=texto_h.get()
        fun=f+","+g+","+h
        fun=fun.replace("x","X[0]")
        fun=fun.replace("y","X[1]")
        fun=fun.replace("z","X[2]")
        zz=eval(fun)
        return zz
    def _punto_c(self):
        global f,g,h,x0,y0,ultima_accion,color_curva
        global color_punto
        global x_min,x_max,y_min,y_max,t_min,t_max,t_n,z_min,z_max
        self.OK_3()
        solu_dx=[]
        solu_dy=[]
        solu_dz=[]
        h=abs(t_min-t_max)/t_n
        X_a=np.arange(x_min,x_max,1)
        Y_a=np.arange(y_min,y_max,1)
        Z_a=np.arange(z_min,z_max,1)
        for i in range(0,len(X_a)):
            for j in range(0,len(Y_a)):
                for k in range(0,len(Z_a)):
                    X=[X_a[i],Y_a[j],Z_a[k]]
                    solu=fsolve(self.funcion_p,X)
                    if solu_dx==[] and solu_dy==[]:
                        solu_dx.append(solu[0])
                        solu_dy.append(solu[1])
                        solu_dz.append(solu[2])
                        self._tipo_punto(solu[0],solu[1],solu[2])
                    else:
                        x_t=Me._f_3D(f,solu[0],solu[1],solu[2],0)
                        y_t=Me._g_3D(g,solu[0],solu[1],solu[2],0)
                        z_t=Me._h_3D(h,solu[0],solu[1],solu[2],0)
                        if -0.01<x_t<0.01 and -0.01<y_t<0.01 and-0.01<z_t<0.01:
                            solu_dx.append(solu[0])
                            solu_dy.append(solu[1])
                            solu_dz.append(solu[2])
                            self._tipo_punto(solu[0],solu[1],solu[2])
        self.a_3d.plot(solu_dx,solu_dy,solu_dz,'o',color=color_punto)
        self.axy.plot(solu_dx,solu_dy,'o',color=color_punto)
        self.ayz.plot(solu_dy,solu_dz,'o',color=color_punto)
        self.axz.plot(solu_dx,solu_dz,'o',color=color_punto)
        ultima_accion.append("linea")
        self.canvas.show()
    def _tipo_punto(self,x,y,z):
        pass

    def _vectorial(self):#not finished

        global f,g,h,x_min, x_max, y_min,y_max,z_min,z_max, t_n,t0
        
        fig_vector=plt.figure()
        vect_3d=fig_vector.add_subplot(111,projection="3d")

        self.OK_3()
        xv=linspace(x_min,x_max,t_n)
        yv=linspace(y_min,y_max,t_n)
        zv=linspace(z_min,z_max,t_n)
        DVX=zeros((t_n,t_n,t_n))
        DVY=zeros((t_n,t_n,t_n))
        DVZ=zeros((t_n,t_n,t_n))
        xv1,yv1,zv1,=meshgrid(linspace(x_min,x_max,t_n),linspace(y_min,y_max,t_n),linspace(z_min,z_max,t_n))
        for i in range(0,len(xv)-1):
            for j in range(0,len(yv)-1):
                for k in range(0,len(zv)-1):
                    
                    DVX[k][j][i]=Me._f_3D(f,xv[k],yv[j],zv[i],t0)
                    DVY[k][j][i]=Me._g_3D(g,xv[k],yv[j],zv[i],t0)
                    DVZ[k][j][i]=Me._h_3D(h,xv[k],yv[j],zv[i],t0)
                    M=np.sqrt(DVX[k][j][i]*DVX[k][j][i]+DVY[k][j][i]*DVY[k][j][i]+DVZ[k][j][i]*DVZ[k][j][i])
                if M==0:
                    M=1.
                DVX[k][j][i]/=M
                DVY[k][j][i]/=M
                DVZ[k][j][i]/=M
        
        vect_3d.set_xlim([x_min,x_max])
        vect_3d.set_ylim([y_min,y_max])
        vect_3d.set_zlim([z_min,z_max])
        vect_3d.set_xlabel('x(t)')
        vect_3d.set_ylabel('y(t)')
        vect_3d.set_zlabel('z(t)')
        vect_3d.grid(True)
        Q3d=vect_3d.quiver(xv1,yv1,zv1,DVX,DVY,DVZ,M,length=0.5,linewidth=.5,pivot='middle',color="#0000FF")
        

        fig_vector.show()

        
    def _Xt_Yt(self):
        global X,Y,Z,X1,Y1,Z1,t_min,t_max,t_n,x_min,y_min,z_min,x_max,y_max,z_max
        T1=[0]
        T2=[t_min]
        h=t_max/t_n
        for i in range(1,int(t_n)+1):
            T1.append(T1[-1]+h)
            T2.append(T2[-1]+h)
        if len(X)<len(T1):
            del T1[len(X):]
        if len(X1)<len(T2):
            del T2[0:len(T2)-len(X1)]
        fig_ft=plt.figure()
        c=fig_ft.add_subplot(311)
        c.set_xlim([t_min,t_max])
        c.set_ylim([x_min,x_max])
        c.set_xlabel('t')
        c.set_ylabel('X(t)')
        c.plot(T1,X,color="#0000FF")
        c.plot(T2,X1,color="#0000FF")
        c=fig_ft.add_subplot(312)
        c.set_xlim([t_min,t_max])
        c.set_ylim([y_min,y_max])
        c.set_xlabel('t')
        c.set_ylabel(' Y(t)')
        c.plot(T1,Y,color="#00FF00")
        c.plot(T2,Y1,color="#00FF00")
        c=fig_ft.add_subplot(313)
        c.set_xlabel('t')
        c.set_ylabel('Z(t)')
        c.plot(T1,Z,color="#FF0000")
        c.plot(T2,Z1,color="#FF0000")
        c.grid(True)
        fig_ft.show()
        X,Y,Z=[],[],[]
        X1,Y1,Z1=[],[],[]
        

    def _pendiente(self):#placeholder ojo eso son superficies
        self.OK()
        self.OK()
        mx=texto_mx.get()
        my=texto_my.get()
        mz=texto_mz.get()
        if mx !="":
            xm=linspace(x_min,x_max,t_n)
            ym=[]
            zm=texto_pz.get()
            for i in range(0,len(xm)):
                ym.append(self._pxy(xm[i],zm))
            self.axy.plot(xm,ym,color=color_curva_1)
            #self._sxyz()
            #ultima_accion.append("linea")
            self.canvas.show()
        elif my !="":
            xm=texto_px.get()
            ym=linspace(y_min,y_max,t_n)
            zm=[]
            for i in range(0,len(ym)):
                zm.append(self._pyz(ym[i],xm))
            self.ayz.plot(ym,zm,color=color_curva_2)
            #self._sxyz()
            #ultima_accion.append("linea")
            self.canvas.show()
        else:
            xm=[]
            ym=texto_py.get()
            zm=linspace(z_min,z_max,t_n)
            for i in range(0,len(zm)):
                xm.append(self._pxz(zm[i],ym))
            self.axz.plot(zm,xm,color=color_curva_2)
            #self._sxyz()
            #ultima_accion.append("linea")
            self.canvas.show()
        
    def _implicita(self):#placeholder
        pass

    def _undo(self):#placeholder
        pass
    
    def _pxy(self,y,pz):
        m=texto_mx.get()
        n=m.replace("z",pz)
        return eval(n)
    def _pyz(self,z,px):
        m=texto_my.get()
        n=m.replace("x",px)
        return eval(n)
    def _pxz(self,x,py):
        m=texto_mz.get()
        n=m.replace("y",py)
        return eval(n)
    def _sxyz(self,x,y,z):
        mx=texto_mx.get()
        my=texto_my.get()
        mz=texto_mz.get()
        if mx!="":
            pass
        elif my!="":
            pass
        elif mz!="":
            pass

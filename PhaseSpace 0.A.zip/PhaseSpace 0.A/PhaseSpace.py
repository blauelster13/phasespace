#!/usr/bin/env python
# -*- coding: cp1252 -*-
#------------------------------------------
#--------------PhaseSpace 0.A0-------------
#-----Programado por Anton Ferre Pujol-----
#------------------------------------------
# compatible with python 2 and 3

import matplotlib
matplotlib.use('TkAgg')
from numpy import sin, cos, tan, exp, linspace, meshgrid, hypot, zeros, log
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from scipy.integrate import odeint
from sys import version_info
if version_info[0] < 3:
    from Tkinter import Tk, Canvas, Label, Button, Menu, Entry 
    import Tkinter as Tk
    from tkColorChooser import askcolor
else:
    from tkinter import Tk, Canvas, Label, Button, Menu, Entry
    import tkinter as Tk
    from tkinter.colorchooser import askcolor
import time


import metodos as Me
import UI_2
import UI_3
import UI_2_It
import UI_3_It

#-----Language and configuration-----
version="0.A"
screen_res="1200x600"
language_sel=""
pantalla_completa=True
#label_list_2D=["y=m(x):","x=m(y)"]
#label_list_3D=[]
#menu_list=[]

def language_choice():
    language_list=[]
    for i in range(0,len(language_list-1)):
        if language_sel==language_list[i]:
            pass #Pick language file and change the variables accordingly

#-----choice_screen-----

ventana_p=""
ventana1=""
#-----globals-----
color_curva_1,color_curva_2, color_fase, color_punto="#800040","#800040","#0080FF","#FF8000"
color_X, color_Y, color_Z="#0000FF","#00FF00","#FF0000"
color_fondo="#EEEEEE"
ventana=""
ventana_x=1210
ventana_y=600
x_min,x_max,x_n=0.,10.,10.
y_min,y_max,y_n=0.,10.,10.
z_min,z_max,z_n=0.,10.,10.
t_min,t_max,t_n=0.,10.,100.
x0,y0,z0=0,0,0
f,g,h,m,n="","","","",""
fun_f,fun_g,fun_h=0,0,0
X,X1,XF=[],[],[]
Y,Y1=[],[]

texto_t_min,texto_t_max,texto_t_n,texto_t0=0,0,0,0
texto_x_min,texto_x_max,texto_x0,texto_f,texto_mx=0,0,0,0,0
texto_y_min,texto_y_max,texto_y0,texto_g,texto_my=0,0,0,0,0
texto_z_min,texto_z_max,texto_z0,texto_h,texto_mz=0,0,0,0,0
texto_px,texto_py,texto_pz=0,0,0
L_F_fx_fy,L_F_sistema="",""
label_t_n,label_f,label_g,label_x0,label_y0,label_t0="","","","","",""
label_t_min,label_t_max,label_mx,label_my="","","",""
canvas_2D=0
metodo_integracion=""
ultima_accion=[]
Q1=[]
es_implicita=False
implicita=""
#-------------------------
#-----choice_screen-----

ventana_p=""
#-----Start the Splashscreen-----
def splash_screen():
    global ventana1
    ventana1 = Tk.Tk()
    imv1=Tk.PhotoImage(file="./iconos/splash.gif")
    ventana1.geometry("800x600")
    ventana1.overrideredirect(True)
    canvas1=Tk.Canvas(ventana1,width=800,height=600, relief=Tk.FLAT)
    canvas1.image=imv1
    canvas1.create_image((402,302),image=imv1)
    canvas1.pack()
    ventana1.after(5000,inicia)

#-----funciones-----
def inicia():
    global ventana_p
    label_names=["ODE","2  var","3  var","var","Discreet systems","2 var","3 var"]
    button_name="Start"
    ventana1.destroy()
    ventana_p=Tk.Tk()
    ventana_p.wm_title("PhaseSpace "+chr(223)+version)
    ventana_p.geometry("400x300")
    ventana_p.configure(background=color_fondo)
    ventana_p.iconbitmap("icono.ico")

    Frame_ODE=Tk.LabelFrame(ventana_p,text=label_names[0],width=100,height=100)
    Frame_ODE.place(x=10, y=20)
    Label_2=Tk.Label(Frame_ODE,text=label_names[1])
    Label_2.place(x=10, y=10)
    Label_3=Tk.Label(Frame_ODE,text=label_names[2])
    Label_3.place(x=10, y=40)
    #Text_N=Tk.Entry(ventana_p,text="",width=3)
    #Text_N.place(x=10, y=120)
    #Label_N=Tk.Label(ventana_p,text=label_names[3])
    #Label_N.place(x=30, y=120)
    
    Frame_d=Tk.LabelFrame(ventana_p,text=label_names[4],width=100,height=100)
    Frame_d.place(x=140, y=20)
    Label_d_2=Tk.Label(Frame_d,text=label_names[5])
    Label_d_2.place(x=10, y=10)
    Label_d_3=Tk.Label(Frame_d,text=label_names[6])
    Label_d_3.place(x=10, y=40)
    
    button_o2v = Tk.Button(master=Frame_ODE, text=button_name,command=call_interfaz_2D)
    button_o2v.place(x=50,y=10)
    button_o3v = Tk.Button(master=Frame_ODE, text=button_name,command=call_interfaz_3D)
    button_o3v.place(x=50,y=40)
    #button_oNv=Tk.Button(master=ventana_p, text=button_name,command=call_interfaz_n)
    #button_oNv.place(x=50,y=120)

    button_d2v=Tk.Button(master=Frame_d, text=button_name,command=call_interfaz_itera_2)
    button_d2v.place(x=50,y=10)
    button_d3v=Tk.Button(master=Frame_d, text=button_name,command=call_interfaz_itera_3)
    button_d3v.place(x=50,y=40)

#-----Main UI-----
def call_interfaz_2D():
    global ventana_p
    ventana_p.destroy()
    ventana_2D=Tk.Tk()
    UI_2.interfaz_2D(ventana_2D)

def call_interfaz_3D():
    global ventana_p
    ventana_p.destroy()
    ventana_3D=Tk.Tk()
    UI_3.interfaz_3D(ventana_3D)

def call_interfaz_n():
    global ventana_p
    v=Text_N.get()
    ventana_p.destroy()
    ventana_N=Tk.Tk()
    UI_N.interfaz_N(ventana_N,v)

def call_interfaz_itera_2():
    global ventana_p
    ventana_p.destroy()
    ventana_itera_2=Tk.Tk()
    UI_2_It.interfaz_2D(ventana_itera_2)
def call_interfaz_itera_3():
    global ventana_p
    ventana_p.destroy()
    ventana_itera_3=Tk.Tk()
    UI_3_It.interfaz_3D(ventana_itera_3)
#-----Start the main program-----

splash_screen()
Tk.mainloop()

#!/usr/bin/env python
# -*- coding: cp1252 -*-
#------------------------------------------
#--------------PhaseSpace 0.9--------------
#-------------Numerical Methods------------
#-----Programado por Anton Ferre Pujol-----
#------------------------------------------
from numpy import sin, cos, tan, exp, linspace, meshgrid
from scipy.optimize import fsolve
x1=""
y1=""
f1=""
g1=""
e=""


def RK4_2D(f,g,_f,_g,x0,y0,t_min,t_max,x_n):
    vx,vy,vt=[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vt.append(t_min)
    for i in range(1,abs(int(x_n))+1):
        try:
            x=vx[i-1]
            y=vy[i-1]
            t=vt[i-1]
            k1x=e*_f(f,x,y,t)
            k1y=e*_g(g,x,y,t)
            k2x=e*_f(f,x+0.5*k1x,y+0.5*k1y,t+0.5*e)
            k2y=e*_g(g,x+0.5*k1x,y+0.5*k1y,t+0.5*e)
            k3x=e*_f(f,x+0.5*k2x,y+0.5*k2y,t+0.5*e)
            k3y=e*_g(g,x+0.5*k2x,y+0.5*k2y,t+0.5*e)
            k4x=e*_f(f,x+k3x,    y+k3y,    t+e)
            k4y=e*_g(g,x+k3x,    y+k3y,    t+e)
            vx.append(x+(k1x+k2x*2+k3x*2+k4x)/6)
            vy.append(y+(k1y+k2y*2+k3y*2+k4y)/6)
            vt.append(t+e)
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
    return vx,vy

def RK4_3D(f,g,h,_f,_g,_h,x0,y0,z0,t_min,t_max,x_n):
    vx,vy,vz,vt=[],[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vz.append(z0)
    vt.append(t_min)
    for i in range(1,abs(int(x_n))+1):
        try:
            x=vx[i-1]
            y=vy[i-1]
            z=vz[i-1]
            t=vt[i-1]
            k1x=e*_f_3D(f,x,y,z,t)
            k1y=e*_g_3D(g,x,y,z,t)
            k1z=e*_h_3D(h,x,y,z,t)
            k2x=e*_f_3D(f,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,t+0.5*e)
            k2y=e*_g_3D(g,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,t+0.5*e)
            k2z=e*_h_3D(h,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,t+0.5*e)
            k3x=e*_f_3D(f,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,t+0.5*e)
            k3y=e*_g_3D(g,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,t+0.5*e)
            k3z=e*_h_3D(h,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,t+0.5*e)
            k4x=e*_f_3D(f,x+k3x,    y+k3y,    z+k3z,    t+e)
            k4y=e*_g_3D(g,x+k3x,    y+k3y,    z+k3z,    t+e)
            k4z=e*_h_3D(h,x+k3x,    y+k3y,    z+k3z,    t+e)
            vx.append(x+(k1x+k2x*2+k3x*2+k4x)/6)
            vy.append(y+(k1y+k2y*2+k3y*2+k4y)/6)
            vz.append(z+(k1z+k2z*2+k3z*2+k4z)/6)
            vt.append(t+e)
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
            elif len(vz)>len(vx):
                pass
                
    return vx,vy,vz

def RK4_4D(f,g,h,j,_f,_g,_h,_j,x0,y0,z0,w0,t_min,t_max,x_n):
    vx,vy,vz,vw,vt=[],[],[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vz.append(z0)
    vw.append(w0)
    vt.append(t_min)
    for i in range(1,abs(int(x_n))+1):
        try:
            x=vx[i-1]
            y=vy[i-1]
            z=vz[i-1]
            w=vw[i-1]
            t=vt[i-1]
            k1x=e*_f_4D(f,x,y,z,w,t)
            k1y=e*_g_4D(g,x,y,z,w,t)
            k1z=e*_h_4D(h,x,y,z,w,t)
            k1w=e*_j_4D(j,x,y,z,w,t)

            k2x=e*_f_4D(f,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,w+0.5*k1w,t+0.5*e)
            k2y=e*_g_4D(g,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,w+0.5*k1w,t+0.5*e)
            k2z=e*_h_4D(h,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,w+0.5*k1w,t+0.5*e)
            k2w=e*_j_4D(j,x+0.5*k1x,y+0.5*k1y,z+0.5*k1z,w+0.5*k1w,t+0.5*e)

            k3x=e*_f_3D(f,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,w+0.5*k2w,t+0.5*e)
            k3y=e*_g_3D(g,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,w+0.5*k2w,t+0.5*e)
            k3z=e*_h_3D(h,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,w+0.5*k2w,t+0.5*e)
            k3w=e*_h_3D(j,x+0.5*k2x,y+0.5*k2y,z+0.5*k2z,w+0.5*k2w,t+0.5*e)

            k4x=e*_f_3D(f,x+k3x,    y+k3y,    z+k3z,    w+k3w,    t+e)
            k4y=e*_g_3D(g,x+k3x,    y+k3y,    z+k3z,    w+k3w,    t+e)
            k4z=e*_h_3D(h,x+k3x,    y+k3y,    z+k3z,    w+k3w,    t+e)
            k4w=e*_h_3D(j,x+k3x,    y+k3y,    z+k3z,    w+k3w,    t+e)

            vx.append(x+(k1x+k2x*2+k3x*2+k4x)/6)
            vy.append(y+(k1y+k2y*2+k3y*2+k4y)/6)
            vz.append(z+(k1z+k2z*2+k3z*2+k4z)/6)
            vw.append(w+(k1w+k2w*2+k3w*2+k4w)/6)
            vt.append(t+e)
        except OverflowError:
            break
            if len(vx)>len(vy):
                vx.pop(-1)
            if len(vy)>len(vz):
                vy.pop(-1)
            if len(vz)>len(vw):
                vz.pop(-1)
            if len(vw)>len(vx):
                vw.pop(-1)
                
    return vx,vy,vz



def Heun_2D(f,g,_f,_g,x0,y0,t_min,t_max,x_n):
    vx,vy,vt=[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vt.append(t_min)
    for i in range(1,abs(int(x_n))+1):
        try:
            vx1=vx[i-1]+e*_f_2D(f,vx[i-1],vy[i-1],vt[i-1])
            vy1=vy[i-1]+e*_g_2D(g,vx[i-1],vy[i-1],vt[i-1])
            vx.append(vx[i-1]+e*.5*(_f(f,vx[i-1],vy[i-1],vt[i-1])+_f(f,vx1,vy1,vt[i-1])))
            vy.append(vy[i-1]+e*.5*(_g(g,vx[i-1],vy[i-1],vt[i-1])+_g(g,vx1,vy1,vt[i-1])))
            vt.append(vt[i-1]+e)
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
    return vx,vy

def Heun_3D(f,g,h,_f,_g,_h,x0,y0,z0,t_min,t_max,x_n):
    vx,vy,vz,vt=[],[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vz.append(z0)
    vt.append(t_min)
    for i in range(1,abs(int(x_n))+1):
        try:
            vx1=vx[i-1]+e*_f(f,vx[i-1],vy[i-1],vz[i-1],vt[i-1])
            vy1=vy[i-1]+e*_g(g,vx[i-1],vy[i-1],vz[i-1],vt[i-1])
            vz1=vz[i-1]+e*_h(h,vx[i-1],vy[i-1],vz[i-1],vt[i-1])
            vx.append(vx[i-1]+e*.5*(_f(f,vx[i-1],vy[i-1],vz[i-1],vt[i-1])+_f(f,vx1,vy1,vz1,vt[i-1])))
            vy.append(vy[i-1]+e*.5*(_g(g,vx[i-1],vy[i-1],vz[i-1],vt[i-1])+_g(g,vx1,vy1,vz1,vt[i-1])))
            vz.append(vz[i-1]+e*.5*(_h(h,vx[i-1],vy[i-1],vz[i-1],vt[i-1])+_h(h,vx1,vy1,vz1,vt[i-1])))
            vt.append(vt[i-1]+e)
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
    return vx,vy

def I_Euler_2(f,g,x0,y0,t_min,t_max,x_n):
    global x1,y1,e,f1,g1
    vx,vy,vt=[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vt.append(t_min)
    x1,y1=x0,y0
    f1=f.replace("x","X[0]")
    f1=f1.replace("y","X[1]")
    f1="e*"+f1+"+x1-X[0]"
    g1=g.replace("x","X[0]")
    g1=g1.replace("y","X[1]")
    g1="e*"+g1+"+y1-X[1]"
    for i in range(1,abs(int(x_n))+1):
        try:
            X=[vx[i-1],vy[i-1]]
            Z=fsolve(funcion_I,X)
            vx.append(Z[0])
            vy.append(Z[1])
            x1,y1=vx[i],vy[i]
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
    return vx,vy

def I_Heun(f,g,x0,y0,t_min,t_max,x_n):#to do
    global x1,y1,e,f1,g1
    vx,vy,vt=[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vt.append(t_min)
    x1,y1=x0,y0
    f1=f.replace("x","X[0]")
    f1=f1.replace("y","X[1]")
    f1="e*"+f1+"+x1-X[0]"
    g1=g.replace("x","X[0]")
    g1=g1.replace("y","X[1]")
    g1="e*"+g1+"+y1-X[1]"
    for i in range(1,abs(int(x_n))+1):
        try:
            X=[vx[i-1],vy[i-1]]
            Za=fsolve(funcion_I,X)
            Z=fsolve(funcion_Ia,Za)
            x.append(Z[0])
            y.append(Z[1])
            x1,y1=vx[i],vy[i]
        except OverflowError:
            break
            if len(vx)>len(vy):
                vy.pop(-1)
            elif len(vy)>len(vx):
                vx.pop(-1)
    return vx,vy

def Gears4_2(f,g,x0,y0,t_min,t_max,x_n):
    global x1,y1,e,f1,g1
    vx,vy,vt=[],[],[]
    e=(t_max-t_min)/x_n
    vx.append(x0)
    vy.append(y0)
    vt.append(t_min)
    x1,y1=x0,y0
    f1=f.replace("x","X[0]")
    f1=f1.replace("y","X[1]")
    f1="e*"+f1+"+x1-X[0]"
    g1=g.replace("x","X[0]")
    g1=g1.replace("y","X[1]")
    g1="e*"+g1+"+y1-X[1]"
    #finish this
def funcion_I(X):
    global x1,y1,e,f1,g1
    X0=[x1,y1]
    z=eval(X0[0]+e*f1+","+X0[1]+e*g1)
    return z
def funcion_Ia(X):
    global x1, y1,e,f1,g1
    X0=[x1,y1]
    z=X+e*0.5*(eval(f1+","+g1))
    return z
    
    
def _f_2D(f,x,y,t):
    return eval(f)

def _g_2D(g,x,y,t):
    return eval(g)

def _f_3D(f,x,y,z,t):
    return eval(f)

def _g_3D(g,x,y,z,t):
    return eval(g)

def _h_3D(h,x,y,z,t):
    return eval(h)

def _f_4D(f,x,y,z,w,t):
    return eval(f)

def _g_4D(g,x,y,z,w,t):
    return eval(g)

def _h_4D(h,x,y,z,w,t):
    return eval(h)
def _j_4D(j,x,y,z,w,t):
    return eval(h)

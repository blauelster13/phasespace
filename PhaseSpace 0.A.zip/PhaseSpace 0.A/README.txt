To use PhaseSpace you will need Python 3 and the libraries Scipy, Numpy and Matplotlib. 
They can be found in the links below:

Python: https://www.python.org/download/releases/3.0/
Scipy: https://www.scipy.org
Numpy: http://www.numpy.org
Matplotlib: http://matplotlib.org

Once you installed them to start the program just doubleclick PhaseSpace.py 
#!/usr/bin/env python
# -*- coding: cp1252 -*-
#------------------------------------------------
#-2 variables user interface for Phase Space 0.A-
#--------Programado por Anton Ferre Pujol--------
#------------------------------------------------
#---------compatible with python 2 and 3---------

import matplotlib
matplotlib.use('TkAgg')
from numpy import sin, cos, tan, exp, linspace, meshgrid, hypot, zeros, log
import numpy as np
import cmath
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.backend_bases import key_press_handler
from matplotlib.figure import Figure
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from scipy.optimize import fsolve
from scipy.integrate import odeint
from sys import version_info
if version_info[0] < 3:
    from Tkinter import Tk, Canvas, Label, Button, Menu, Entry 
    import Tkinter as Tk
    from tkColorChooser import askcolor
else:
    from tkinter import Tk, Canvas, Label, Button, Menu, Entry
    import tkinter as Tk
    from tkinter.colorchooser import askcolor
import time
import metodos as Me
from decimal import Decimal
#-Variables
version="0.A"
screen_res="1200x600"
language_sel=""
pantalla_completa=True
label_list_2D=["y=m(x):","x=m(y)"]
label_list_3D=[]
menu_list=[]



#-----globals-----
color_curva_1,color_curva_2, color_fase, color_punto="#800040","#800040","#0080FF","#FF8000"
color_X, color_Y, color_Z="#0000FF","#00FF00","#FF0000"
color_fondo="#EEEEEE"
ventana=""
ventana_x=1210
ventana_y=600
x_min,x_max,x_n=0.,10.,10.
y_min,y_max,y_n=0.,10.,10.
z_min,z_max,z_n=0.,10.,10.
t_min,t_max,t_n=0.,10.,100.
x0,y0,z0=0,0,0
f,g,h,m,n="","","","",""
fun_f,fun_g,fun_h=0,0,0
X,X1,XF=[],[],[]
Y,Y1=[],[]

texto_t_min,texto_t_max,texto_t_n,texto_t0=0,0,0,0
texto_x_min,texto_x_max,texto_x0,texto_f,texto_mx=0,0,0,0,0
texto_y_min,texto_y_max,texto_y0,texto_g,texto_my=0,0,0,0,0
texto_z_min,texto_z_max,texto_z0,texto_h,texto_mz=0,0,0,0,0
texto_px,texto_py,texto_pz=0,0,0
L_F_fx_fy,L_F_sistema="",""
label_t_n,label_f,label_g,label_x0,label_y0,label_t0="","","","","",""
label_t_min,label_t_max,label_mx,label_my="","","",""
canvas_2D=0
metodo_integracion=""
ultima_accion=[]
Q1=[]
es_implicita=False
implicita=""

text_var_1,text_var_2="",""
text_var_min_1,text_var_max_1,text_var_n_1=0,0,0
text_var_min_2,text_var_max_2,text_var_n_2=0,0,0

#-----Main UI-----
class interfaz_basica(Tk.Frame):
    def __init__(self,parent):
        self.parent=parent
        self.init_UI_2D()
    #-----Common commands-----
    def _quit(self):
        self.parent.quit()     
        self.parent.destroy()
    def on_key_event(self,event):
        pass
    
    def _configuracion(self):
        global screen_res, language, pantalla_completa,color_fondo,version
        global color_curva_1,color_curva_2, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        ventana_conf=Tk.Toplevel()
        ventana_conf.geometry("300x280")
        ventana_conf.wm_title("PhaseSpace "+chr(223)+version+" Config.")
        ventana_conf.iconbitmap("icono.ico")
        ventana_conf.configure(background=color_fondo)
        
        label_conf_bck_color=Tk.Label(master=ventana_conf,text="Background color")
        label_conf_bck_color.place(x=10,y=40)
        button_conf_bck=Tk.Button(master=ventana_conf,text="  ",background=color_fondo, command=lambda: _color(color_fondo))
        button_conf_bck.place(x=120, y=35)
        label_conf_phase=Tk.Label(master=ventana_conf,text="Phase line color")
        label_conf_phase.place(x=10,y=70)
        button_conf_phase_color=Tk.Button(master=ventana_conf,text="  ",background=color_fase, command=lambda: _color(color_fase))
        button_conf_phase_color.place(x=120, y=65)
        label_conf_point=Tk.Label(master=ventana_conf,text="Critical point color")
        label_conf_point.place(x=10,y=100)
        button_conf_point=Tk.Button(master=ventana_conf,text="  ",background=color_punto, command=lambda: _color(color_punto))
        button_conf_point.place(x=120, y=95)

        label_conf_curve_2=Tk.Label(master=ventana_conf,text="Curve color")
        label_conf_curve_2.place(x=10,y=130)
        button_conf_curve_2=Tk.Button(master=ventana_conf,text="  ",background=color_curva_2, command=lambda: _color(color_curva_2))
        button_conf_curve_2.place(x=120, y=125)
        
        label_conf_X_color=Tk.Label(master=ventana_conf,text="X(t) color")
        label_conf_X_color.place(x=10,y=160)
        button_conf_X=Tk.Button(master=ventana_conf,text="  ",background=color_X, command=lambda: _color(color_X))
        button_conf_X.place(x=120, y=155)
        label_conf_Y_color=Tk.Label(master=ventana_conf,text="Y(t) color")
        label_conf_Y_color.place(x=10,y=190)
        button_conf_Y=Tk.Button(master=ventana_conf,text="  ",background=color_Y, command=lambda: _color(color_Y))
        button_conf_Y.place(x=120, y=185)
        label_conf_Z_color=Tk.Label(master=ventana_conf,text="Z(t) color")
        label_conf_Z_color.place(x=10,y=220)
        button_conf_Z=Tk.Button(master=ventana_conf,text="  ",background=color_Z, command=lambda: _color(color_Z))
        button_conf_Z.place(x=120, y=215)

        def _color(variable):
            global color_curva_2,color_curva_1, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
            color_e = askcolor()[1]
            if variable == color_fondo:
                color_fondo=color_e
                return color_fondo
                button_conf_bck.configure(background = color_e)
                self.configure(background = color_e)
                button_conf_bck.place(x=120, y=65)
                
            elif variable == color_fase:
                color_fase= color_e
                return color_fase
                button_conf_phase.configure(background = color_e)
            elif variable == color_punto:
                color_punto= color_e
                return color_punto
                button_conf_point.configure(background = color_e)
            elif variable == color_curva_1:
                color_curva_1= color_e
                return color_curva_1
                button_conf_curve_1.configure(background = color_e)
            elif variable == color_curva_2:
                color_curva_2= color_e
                return color_curva_2
                button_conf_curve_2.configure(background = color_e)
            elif variable == color_X:
                color_X= color_e
                return color_X
                button_X.configure(background = color_e)
            elif variable == color_Y:
                color_Y= color_e
                return color_Y
                button_Y.configure(background = color_e)
            elif variable == color_Z:
                color_Z= color_e
                return color_Z
                button_Z.configure(background = color_e)
            ventana_conf.update()
            self.update()
        
    #-----Loads UI-----
    def init_UI_basica(self):
        global color_curva_1, color_curva_2, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        global texto_x0,texto_y0,texto_x_min,texto_x_max,texto_y_min,texto_y_max,texto_ny,texto_t0
        global texto_t_min,texto_t_max,texto_t_n,texto_f,texto_g,texto_mx,texto_my,canvas,metodo_integracion
        global L_F_fx_fy,L_F_sistema, color_curva, es_implicita
        global label_t_n,label_f,label_g,label_x0,label_y0,label_t_min,label_t_max,label_mx,label_my,label_t0
        label_names=["Axis:","x min:","x max:", "y min:", "y max:","System","x_n+1:","y_n+1:",
                    "x0:","y0:","t0:","n:","t min:","t max:", "",""]
        menu_names=["New project","Save project as","Load data","Exit","File","Undo","Delete data","Delete graph",
                    "Edition","Phase space","Vector field","Solutions","Critical Points",
                    "Horizontal and vertical slope curves","Draw","Set axes","Colors","Config.","Configuration",
                    "Help","About","Help"]
        #-----images and window config-----
        imagen_ejes=Tk.PhotoImage(file="./iconos/ejes.gif")
        imagen_fases=Tk.PhotoImage(file="./iconos/fases.gif")
        imagen_vector=Tk.PhotoImage(file="./iconos/vector.gif")
        imagen_soluciones=Tk.PhotoImage(file="./iconos/soluciones.gif")
        imagen_borra_f=Tk.PhotoImage(file="./iconos/borra_f.gif")
        imagen_borra_d=Tk.PhotoImage(file="./iconos/borra_d.gif")
        imagen_undo=Tk.PhotoImage(file="./iconos/undo.gif")
        imagen_puntos=Tk.PhotoImage(file="./iconos/puntos.gif")
        imagen_curvas=Tk.PhotoImage(file="./iconos/curvas.gif")
        imagen_color=Tk.PhotoImage(file="./iconos/color.gif")
        imagen_implicita=Tk.PhotoImage(file="./iconos/implicita.gif")

        self.parent.wm_title("PhaseSpace "+chr(223)+version)
        self.parent.geometry(screen_res)
        self.parent.configure(background=color_fondo)
        self.parent.iconbitmap("icono.ico")
        #-----Menu bar-----
        barra_menu=Tk.Menu(self.parent)
        self.parent.configure(menu=barra_menu)
        archivo_menu=Tk.Menu(barra_menu)
        archivo_menu.add_command(label=menu_names[0],command=self._nuevo_proyecto)
        archivo_menu.add_command(label=menu_names[1],command=self._guarda_proyecto_como)
        archivo_menu.add_command(label=menu_names[2],command=self._abre_proyecto)
        archivo_menu.add_command(label=menu_names[3],command=self._quit)
        barra_menu.add_cascade(label=menu_names[4], menu=archivo_menu)
        edicion_menu=Tk.Menu(barra_menu)
        edicion_menu.add_command(label=menu_names[5],command=self._undo)
        edicion_menu.add_command(label=menu_names[6],command=self._borra_datos)
        edicion_menu.add_command(label=menu_names[7],command=self._borra_grafica)
        barra_menu.add_cascade(label=menu_names[8], menu=edicion_menu)
        dibuja_menu=Tk.Menu(barra_menu)
        dibuja_menu.add_command(label=menu_names[9],command=self._fases)
        dibuja_menu.add_command(label=menu_names[10],command=self._vectorial)
        dibuja_menu.add_command(label=menu_names[11],command=self._Xt_Yt)
        dibuja_menu.add_command(label=menu_names[12],command=self._punto_c)
        dibuja_menu.add_command(label=menu_names[13],command=self._pendiente)

        barra_menu.add_cascade(label=menu_names[14], menu=dibuja_menu)
        configuracion_menu=Tk.Menu(barra_menu)
        configuracion_menu.add_command(label=menu_names[15],command=self._ejes)
        configuracion_menu.add_command(label=menu_names[16],command=self._configuracion)
        configuracion_menu.add_command(label=menu_names[17],command=self._configuracion)
        barra_menu.add_cascade(label=menu_names[18], menu=configuracion_menu)
        ayuda_menu=Tk.Menu(barra_menu)
        ayuda_menu.add_command(label=menu_names[19])
        ayuda_menu.add_command(label=menu_names[20])
        ayuda_menu.add_cascade(label=menu_names[21],menu=ayuda_menu)
        #-----Buttons-----
        button_ejes = Tk.Button(master=self.parent, text='Ejes', image=imagen_ejes,command=self._ejes, width=32,height=32)
        button_ejes.image=imagen_ejes
        button_ejes.place(x=10,y=10)
        button_Vectorial = Tk.Button(master=self.parent, text='C. Vectorial', image =imagen_vector, command=self._vectorial,width=32,height=32)
        button_Vectorial.image=imagen_vector
        button_Vectorial.place(x=50,y=10)
        button_Fases = Tk.Button(master=self.parent, text='Mapa de Fases', image=imagen_fases,command=self._fases,width=32,height=32)
        button_Fases.image=imagen_fases
        button_Fases.place(x=90,y=10)
        button_Pcritico = Tk.Button(master=self.parent, text='P. Critico', image=imagen_puntos,command=self._punto_c, width=32,height=32)
        button_Pcritico.image=imagen_puntos
        button_Pcritico.place(x=130,y=10)
        button_PendienteC = Tk.Button(master=self.parent, text='Pendiente', image=imagen_curvas,command=self._pendiente,  width=32,height=32)
        button_PendienteC.image=imagen_curvas
        button_PendienteC.place(x=170,y=10)
        button_Implicita = Tk.Button(master=self.parent, text='implicita', image=imagen_implicita,command=self._implicita, width=32, height=32)
        button_Implicita.image=imagen_implicita
        button_Implicita.place(x=210,y=10)
        button_Soluciones=Tk.Button(master=self.parent, text='f(t)', image=imagen_soluciones,command=self._Xt_Yt,  width=32,height=32)
        button_Soluciones.image=imagen_soluciones
        button_Soluciones.place(x=250,y=10)
        button_Deshacer = Tk.Button(master=self.parent, text='Undo', image=imagen_undo,command=self._undo, width=32,height=32)
        button_Deshacer.image=imagen_undo
        button_Deshacer.place(x=290,y=10)
        button_Borrar_D = Tk.Button(master=self.parent, text='Borrar Datos', image=imagen_borra_d, command=self._borra_datos,width=32,height=32)
        button_Borrar_D.image=imagen_borra_d
        button_Borrar_D.place(x=330,y=10)
        button_Borrar_G = Tk.Button(master=self.parent, text='Borrar Grafica', image=imagen_borra_f,command=self._borra_grafica, width=32,height=32)
        button_Borrar_G.image=imagen_borra_f
        button_Borrar_G.place(x=370,y=10)
        button_Color = Tk.Button(master=self.parent, text='Color', image=imagen_color,command=self._configuracion, width=32,height=32)
        button_Color.image=imagen_color
        button_Color.place(x=410,y=10)
 
        
        
        #-----Labels and text entries-----
        L_F_fx_fy=Tk.LabelFrame(master=self.parent,text=label_names[0],width=245,height=80)
        L_F_fx_fy.configure(background=color_fondo)
        L_F_fx_fy.place(x=10,y=80)
        label_x_min=Tk.Label(master=self.parent,text=label_names[1], font=("Helvetica",9),width=6)
        label_x_min.configure(background=color_fondo)
        label_x_min.place(x=20, y=105)
        texto_x_min=Tk.Entry(master=self.parent,width=9)
        texto_x_min.place(x=70,y=105)
        label_x_max=Tk.Label(master=self.parent,text=label_names[2],font=("Helvetica",9), width=6)
        label_x_max.configure(background=color_fondo)
        label_x_max.place(x=135, y=105)
        texto_x_max=Tk.Entry(master=self.parent,width=9)
        texto_x_max.place(x=185,y=105)
        label_y_min=Tk.Label(master=self.parent,text=label_names[3],font=("Helvetica",9), width=6)
        label_y_min.configure(background=color_fondo)
        label_y_min.place(x=20, y=130)
        texto_y_min=Tk.Entry(master=self.parent,width=9)
        texto_y_min.place(x=70,y=130)
        label_y_max=Tk.Label(master=self.parent,text=label_names[4],font=("Helvetica",9), width=6)
        label_y_max.configure(background=color_fondo)
        label_y_max.place(x=135, y=130)
        texto_y_max=Tk.Entry(master=self.parent,width=9)
        texto_y_max.place(x=185,y=130)

        L_F_sistema=Tk.LabelFrame(master=self.parent,text=label_names[5],font=("Helvetica",9),width=595,height=180)
        L_F_sistema.configure(background=color_fondo)
        L_F_sistema.place(x=10,y=200)
        label_f=Tk.Label(master=self.parent,text=label_names[6], font=("Helvetica",9),width=6)
        label_f.configure(background=color_fondo)
        label_f.place(x=20, y=225)
        texto_f=Tk.Entry(master=self.parent,font=("Helvetica",9),width=74)
        texto_f.place(x=70,y=225)
        label_g=Tk.Label(master=self.parent,text=label_names[7], font=("Helvetica",9),width=6)
        label_g.configure(background=color_fondo)
        label_g.place(x=20, y=250)
        texto_g=Tk.Entry(master=self.parent,font=("Helvetica",9),width=74)
        texto_g.place(x=70,y=250)
        label_x0=Tk.Label(master=self.parent,text=label_names[8], font=("Helvetica",9),width=6)
        label_x0.configure(background=color_fondo)
        label_x0.place(x=20, y=275)
        texto_x0=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_x0.place(x=70,y=275)
        label_y0=Tk.Label(master=self.parent,text=label_names[9],font=("Helvetica",9), width=6)
        label_y0.configure(background=color_fondo)
        label_y0.place(x=135, y=275)
        texto_y0=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_y0.place(x=185,y=275)

        label_t_n=Tk.Label(master=self.parent,text=label_names[11], font=("Helvetica",9),width=6)
        label_t_n.configure(background=color_fondo)
        label_t_n.place(x=250, y=275)
        texto_t_n=Tk.Entry(master=self.parent,font=("Helvetica",9),width=8)
        texto_t_n.place(x=300,y=275)

        label_mx=Tk.Label(master=self.parent,text='y_n+1=m(x):', font=("Helvetica",9),width=6)
        label_mx.configure(background=color_fondo)
        label_mx.place(x=20, y=325)
        texto_mx=Tk.Entry(master=self.parent,font=("Helvetica",9),width=41)
        texto_mx.place(x=70,y=325)
        label_my=Tk.Label(master=self.parent,text='x_n+1=m(y):',font=("Helvetica",9), width=6)
        label_my.configure(background=color_fondo)
        label_my.place(x=20, y=350)
        texto_my=Tk.Entry(master=self.parent,font=("Helvetica",9),width=41)
        texto_my.place(x=70,y=350)

        label_log=Tk.Label(master=self.parent,text="Log:",font=("Helvetica",9), width=6)
        label_log.place(x=20,y=425)
        frame_log=Tk.Frame(master=self.parent)
        texto_log=Tk.Text(master=frame_log,width=70,height=5)
        barra_log=Tk.Scrollbar(master=frame_log)
        texto_log.configure(yscrollcommand=barra_log.set)
        barra_log.config(command=texto_log.yview)
        frame_log.place(x=20,y=450)
        texto_log.pack(side=Tk.LEFT)
        barra_log.pack(side=Tk.RIGHT, fill=Tk.Y)

#-----2 variable UI-----
class interfaz_2D(interfaz_basica):
    
    def __init__(self,parent):
        self.parent=parent
        self.init_UI_basica()
        self.fig=Figure(figsize=(5.8,5.3), dpi=100)
        self.fig.subplots_adjust(bottom=0.1,right=0.95,top=0.9, left=0.1)
        self.a=self.fig.add_subplot(111)
        self.canvas=self.init_Canvas()
        self._borra_datos()
        
    def init_Canvas(self):
        canvas_2D = FigureCanvasTkAgg(self.fig, master=self.parent)
        canvas_2D.show()
        canvas_2D.get_tk_widget().pack(side=Tk.TOP, fill=Tk.BOTH, expand=1)
        toolbar = NavigationToolbar2TkAgg( canvas_2D, self.parent )
        toolbar.update()
        canvas_2D._tkcanvas.place(x=610,y=10)
        canvas_2D.mpl_connect('key_press_event', self.on_key_event)
        canvas_2D.mpl_connect('button_press_event', self.on_click)
        return canvas_2D
    def _importa_metodos(self):
        pass
    def _nuevo_proyecto(self):
        ventana_2D.destroy()
        inicia()
        
    def _borra_datos(self):
       
        texto_t_n.delete(0,'end')
        texto_t_n.insert(0,100)
        texto_x_min.delete(0,'end')
        texto_x_max.delete(0,'end')
        texto_x0.delete(0,'end')
        texto_x_min.insert(0,-5)
        texto_x_max.insert(0,5)
        texto_x0.insert(0,0)
        texto_y_min.delete(0,'end')
        texto_y_max.delete(0,'end')
        texto_y0.delete(0,'end')
        texto_y_min.insert(0,-4)
        texto_y_max.insert(0,4)
        texto_y0.insert(0,0)
        texto_f.delete(0,'end')
        texto_g.delete(0,'end')
        texto_f.insert(0,"")
        texto_g.insert(0,"")
        texto_mx.delete(0,'end')
        texto_mx.insert(0,"")
        texto_my.delete(0,'end')
        texto_my.insert(0,"")
        self._ejes()

    def _ejes(self):
        global x_min, x_max, y_min, y_max,t_min,t_max
        x_min=float(texto_x_min.get())
        x_max=float(texto_x_max.get())
        y_min=float(texto_y_min.get())
        y_max=float(texto_y_max.get())
        self.a.set_xlim([x_min,x_max])
        self.a.set_ylim([y_min,y_max])
        self.canvas.show()
    
    def OK(self):
        global t_min,t_max,t_n,x0,y0,f,g,x_n,y_n,metodo_integracion,t0
        self._ejes()
        
        t_n=float(texto_t_n.get())
        x0=float(texto_x0.get())
        y0=float(texto_y0.get())
        
        f=texto_f.get()
        g=texto_g.get()
    def on_click(self,event):
        global x0,y0,ultima_accion,Q1
        global canvas_2D
        global color_curva, color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        boton_mouse=event.button
        if boton_mouse==1:
            texto_x0.delete(0,'end')
            texto_x0.insert(0,event.xdata)
            texto_y0.delete(0,'end')
            texto_y0.insert(0,event.ydata)
            self.OK()
            self._fases()
            ultima_accion.append("linea")
        if boton_mouse==3:
            texto_x0.delete(0,'end')
            texto_x0.insert(0,event.xdata)
            texto_y0.delete(0,'end')
            texto_y0.insert(0,event.ydata)
            x0=float(texto_x0.get())
            y0=float(texto_y0.get())
            M1=(hypot(x0-Me._f_2D(f,x0,y0,0),y0-Me._g_2D(g,x0,y0,0)))
            if M1==0:
                M1=1.
            dx1=(Me._f_2D(f,x0,y0,0))/M1
            dy1=(Me._g_2D(g,x0,y0,0))/M1
            flecha=self.a.quiver(x0,y0,dx1,dy1,pivot='mid',color=color_fase)
            Q1.append(flecha)
            self.canvas.show()
            ultima_accion.append("flecha")

    def _borra_grafica(self):
        self.a.cla()
        self._ejes()
        self.canvas.show()

    def _fases(self):
        global f,g,X,X1,Y,Y1
        global color_fase
        global x_min,x_max,y_min,y_max,t_min,t_max,t_n,x0,y0,metodo_integracion,ultima_accion
        self.OK() 
        X,Y=[],[]
        X.append(x0)
        Y.append(y0)
        for i in range(0,int(t_n)-1):
            x,y=X[i],Y[i]
            X.append(eval(f))
            Y.append(eval(g))
        self.a.plot(X,Y,color_fase)
        self.a.set_xlabel('x_n+1')
        self.a.set_ylabel('y_n+1')
        self.a.grid(True)
        self.canvas.show()
  
    def funcion_p(self,X):
        global f,g
        f1=f+"-x"
        g1=g+"-y"
        fun=f1+","+g1
        fun=fun.replace("x","X[0]")
        fun=fun.replace("y","X[1]")
        z=eval(fun)
        return z
    def _punto_c(self):
        global f,g,x0,y0,ultima_accion,color_curva
        global color_punto
        global x_min,x_max,y_min,y_max,t_min,t_max,t_n
        self.OK()
        solu_dx=[]
        solu_dy=[]
        h=abs(t_min-t_max)/t_n
        X_a=np.arange(x_min,x_max,1)
        Y_a=np.arange(y_min,y_max,1)
        for i in range(0,len(X_a)):
            for j in range(0,len(Y_a)):
                X=[X_a[i],Y_a[j]]
                solu=fsolve(self.funcion_p,X)
                if abs(solu[0])<0.001:
                    solu[0]=0
                elif abs(solu[1])<0.001:
                    solu[1]=0
                x_t=Me._f_2D(f,solu[0],solu[1],0)
                y_t=Me._g_2D(g,solu[0],solu[1],0)
                if -0.01<x_t<0.01 and -0.01<y_t<0.01:
                    solu_dx.append(solu[0])
                    solu_dy.append(solu[1])
                    TP=self._tipo_punto(solu[0],solu[1])
                    print("x=%s"%solu[0],"y=%s"%solu[1],"l1=%s"%TP[0],"l2=%s"%TP[1])
        self.a.plot(solu_dx,solu_dy,'o',color=color_punto)
        ultima_accion.append("linea")
        self.canvas.show()
    def _tipo_punto(self,x,y):
        global f,g
        def_dex=self.deriva(f,x,y)
        def_dey=self.deriva(f,y,x)
        deg_dex=self.deriva(g,x,y)
        deg_dey=self.deriva(g,y,x)
        C_p=(-1)*(def_dex+deg_dey)
        B_p=(def_dex*deg_dey)-(def_dey*deg_dex)
        print(B_p,C_p)
        l1=(-B_p+cmath.sqrt((B_p**2)-4*C_p))/2
        l2=(-B_p-cmath.sqrt((B_p**2)-4*C_p))/2
        return l1,l2
    def deriva(self,f,x,y):
        h=0.1
        x=x+(h/2)
        d1=eval(f)
        x=x-h
        d2=eval(f)
        d=(d1-d2)/h
        return d
    def _vectorial(self):
        global fun_f,fun_g,x_min, x_max, y_min,y_max, t_n,t0
        self.OK()
        xv=linspace(x_min,x_max,t_n)
        yv=linspace(y_min,y_max,t_n)
        DVX=zeros((t_n,t_n))
        DVY=zeros((t_n,t_n))
        for i in range(0,len(xv)-1):
            for j in range(0,len(yv)-1):
                DVX[i][j]=Me._f_2D(f,xv[j],yv[i],t0)
                DVY[i][j]=Me._g_2D(g,xv[j],yv[i],t0)
                M=(hypot(DVX[i][j],DVY[i][j]))
                if M==0:
                    M=1.
                DVX[i][j]/=M
                DVY[i][j]/=M
        fig_f=plt.figure()
        b = fig_f.add_subplot(111)
        b.set_xlim([x_min,x_max])
        b.set_ylim([y_min,y_max])
        b.set_xlabel('x(t)')
        b.set_ylabel('y(t)')
        b.grid(True)
        Q=b.quiver(xv,yv,DVX,DVY,M,pivot='mid',color="#0000FF")
        fig_f.show()

    def _Xt_Yt(self):
        global fun_f,fun_g,x_max, y_min,y_max, t_n,t_min,t_max
        global X,Y
        global color_fase, color_punto, color_X, color_Y, color_Z, color_fondo
        self.OK()
        
        N=np.linspace(0,t_n-1,len(X))
        print(N)
        fig_ft=plt.figure()
        c=fig_ft.add_subplot(211)
        c.set_ylim(min(X)-1,max(X)+1)
        c.set_ylabel('x_n+1')
        c.plot(N,X,color=color_X)
        
        c=fig_ft.add_subplot(212)
        
        c.set_ylim(min(Y)-1,max(Y)+1)
        c.set_ylabel('y_n+1')
        c.set_xlabel('n')
        
        c.plot(N,Y,color=color_Y)
        
        c.grid(True)
        fig_ft.show()

    def _pendiente(self):
        global x_min,x_max,t_n,m,n,y_min,y_max,ultima_accion,color_curva_1,color_curva_2
        self.OK()
        m=texto_mx.get()
        n=texto_my.get()
        if m !="":
            xm=linspace(x_min,x_max,t_n)
            ym=[]
            for i in range(0,len(xm)):
                ym.append(self._mx(xm[i]))
            self.a.plot(xm,ym,color=color_curva_2)
            ultima_accion.append("linea")
            self.canvas.show()
        elif n !="":
            xn=[]
            yn=linspace(y_min,y_max,t_n)
            for i in range(0,len(yn)):
                xn.append(self._my(yn[i]))
            self.a.plot(xn,yn,color=color_curva_2)
            ultima_accion.append("linea")
            self.canvas.show()
    def _implicita(self):
        if t_n>1000:
            x_n=1000
            texto_tn.delete(0,"end")
            texto_tn.insert(0,1000)
        xr=linspace(x_min,x_max,x_n)
        yr=linspace(y_min,y_max,x_n)
        x,y=meshgrid(xr,yr)
        z=[]
        F=self._mxy(x,y)
        implicita=self.a.contour(x,y,F,[0],colors=color_curva_2)
        Q1.append(implicita)
        ultima_accion.append("implicita")
        self.canvas.show()
    def _undo(self):
        global ultima_accion,Q1,implicita
        try:
            if ultima_accion[len(ultima_accion)-1]=="linea":
                del(self.a.lines[-1])
                ultima_accion.pop(-1)
            elif ultima_accion[len(ultima_accion)-1]=="flecha":
                Q1.pop(-1).remove()
                ultima_accion.pop(-1)
            elif ultima_accion[len(ultima_accion)-1]=="implicita":
                del implicita #error
                ultima_accion.pop(-1)
            self.canvas.show()
        except IndexError:
            pass

    def _abre_fichero(self):
        ftypes=[('Text files','*.txt'),('All files','*')]
        dlg=Tk.filedialog.Open(self,filetypes=ftypes)
        fl=dlg.show()#nombre del fichero
        print(fl)
        if fl!='':
            texto_fichero=self.readFile(fl)
    def _guarda_proyecto_como(self):
        file_name=tkinter.filedialog.asksaveasfilename()
        if file_name:
            fichero=open(file_name,'w')
            #save_data(fichero)
        
        

    def _abre_proyecto(self):
        file_name=tkinter.filedialog.askopenfilename()
        if file_name:
            fichero=open(file_name,'r')
            self.dibuja_grafica(fichero)


    def dibuja_grafica(self,fichero):
      #fig_p=plt.figure()
      #a=fig_p.add_subplot(111)
      for line in fichero:
        data=line.split("_")
        if data[0]=="l":
          X=data[1].replace("[","").replace(",","").replace("]","").split()
          Y=data[2].replace("[","").replace(",","").replace("]\n","").split()
          for i in range(0,len(X)):
            X[i]=float(X[i])
            Y[i]=float(Y[i])
          #a.plot(X,Y,'b')
        elif data[0]=="p":
          X=data[1].replace("[","").replace(",","").replace("]","").split()
          Y=data[2].replace("[","").replace(",","").replace("]\n","").split()
          X[0]=float(X[0])
          Y[0]=float(Y[0])
          #a.plot(X,Y,'ro')
        elif data[0]=="f":
          pass
        elif data[0]=="q":
          pass
        
    
    def _bif_ventana(self):
        global text_var_min_1,text_var_max_1,text_var_n_1,text_var_1
        global text_var_min_2,text_var_max_2,text_var_n_2,text_var_2
        ventana_bif=Tk.Toplevel()
        ventana_bif.geometry("400x280")
        ventana_bif.wm_title("PhaseSpace "+chr(223)+version+" Config.")
        ventana_bif.iconbitmap("icono.ico")
        ventana_bif.configure(background=color_fondo)
        label_var_1=Tk.Label(master=ventana_bif,text="Variable 1:")
        label_var_1.place(x=10,y=10)
        label_var_min_1=Tk.Label(master=ventana_bif,text="Min:")
        label_var_min_1.place(x=10,y=40)
        label_var_max_1=Tk.Label(master=ventana_bif,text="Max:")
        label_var_max_1.place(x=10,y=70)
        label_var_n_1=Tk.Label(master=ventana_bif,text="n:")
        label_var_n_1.place(x=10,y=100)
        text_var_1=Tk.Entry(master=ventana_bif,text="")
        text_var_1.place(x=70,y=10)
        text_var_min_1=Tk.Entry(master=ventana_bif,text="")
        text_var_min_1.place(x=70,y=40)
        text_var_max_1=Tk.Entry(master=ventana_bif,text="")
        text_var_max_1.place(x=70,y=70)
        text_var_n_1=Tk.Entry(master=ventana_bif,text="")
        text_var_n_1.place(x=70,y=100)

        label_var_2=Tk.Label(master=ventana_bif,text="Variable 2:")
        label_var_2.place(x=150,y=10)
        label_var_min_2=Tk.Label(master=ventana_bif,text="Min:")
        label_var_min_2.place(x=150,y=40)
        label_var_max_2=Tk.Label(master=ventana_bif,text="Max:")
        label_var_max_2.place(x=150,y=70)
        label_var_n_2=Tk.Label(master=ventana_bif,text="n:")
        label_var_n_2.place(x=150,y=100)
        text_var_2=Tk.Entry(master=ventana_bif,text="")
        text_var_2.place(x=210,y=10)
        text_var_min_2=Tk.Entry(master=ventana_bif,text="")
        text_var_min_2.place(x=210,y=40)
        text_var_max_2=Tk.Entry(master=ventana_bif,text="")
        text_var_max_2.place(x=210,y=70)
        text_var_n_2=Tk.Entry(master=ventana_bif,text="")
        text_var_n_2.place(x=210,y=100)

        label_x_min_b=Tk.Label(master=ventana_bif,text="x min:")
        label_x_max_b=Tk.Label(master=ventana_bif,text="x max:")
        label_x_n_b=Tk.Label(master=ventana_bif,text="x n:")
        label_y0_b=Tk.Label(master=ventana_bif,text="y0:")
        text_x_min_b=Tk.Entry(master=ventana_bif,text="")
        text_x_max_b=Tk.Entry(master=ventana_bif,text="")
        text_x_n_b=Tk.Entry(master=ventana_bif,text="")
        text_y0_b=Tk.Entry(master=ventana_bif,text="")

        label_x_min_b.place(x=10, y=130)
        label_x_max_b.place(x=150, y=130)
        label_x_n_b.place(x=290, y=130)
        label_y0_b.place(x=10, y=160)

        text_x_min_b.place(x=70,y=130)
        text_x_max_b.place(x=210,y=130)
        text_x_n_b.place(x=350,y=130)
        text_y0_b.place(x=70,y=160)

        boton_ok_var=Tk.Button(master=ventana_bif,text="1 Variable",command=self._bifurcacion_1)
        boton_ok_var.place(x=10,y=190)
        boton_reset_var=Tk.Button(master=ventana_bif,text="2 Variables",command=self._bifurcacion_2)
        boton_reset_var.place(x=60,y=190)
        boton_clear_var=Tk.Button(master=ventana_bif,text="Clear",command=self._clear_var)
        boton_clear_var.place(x=110,y=190)
    def _clear_var(self):
        pass
    def _bifurcacion_1(self):
        global x0,y0,t_max,t_n,f,g,x_min,x_max
        global text_var_min_1,text_var_max_1,text_var_n_1,text_var_1
        global text_var_min_2,text_var_max_2,text_var_n_2,text_var_2
        self.OK()
        var_name=text_var_1.get()
        var_min=text_var_min_1.get()
        var_max=text_var_max_1.get()
        var_n=text_var_n_1.get()
        v=np.linspace(float(var_min),float(var_max),float(var_n))
        X_b=[]
        Y_b=[]
        fig_bif_1_x=plt.figure()
        b1x=fig_bif_1_x.add_subplot(111)
        b1x.set_xlim([int(var_min)-1,int(var_max)+1])
        b1x.set_xlabel(var_name)
        b1x.set_ylabel('x')
        x_p_n=10
        x_p=np.linspace(x_min,x_max,x_p_n)
        y_p=0
        Y_b.append(y_p)
        for i in range(0,len(x_p)):
            X_b.append(x_p[i])
            for j in range (0,len(v)):
                f1=f.replace(var_name,str(v[j]))
                g1=g.replace(var_name,str(v[j]))
                X_b,Y_b=Me.RK4_2D(f1,g1,Me._f_2D,Me._g_2D,x_p[i],y_p,t0,t_max,t_n)
                if len(X_b)>100:
                    X_b_e=X_b[-100:]
                else:
                    X_b_e=X_b
                    #Y_b_e=Y_b[-100:]
        
                variable=np.ones(len(X_b_e))*v[j]
                b1x.plot(variable,X_b_e,'b.',lw=0.05)
                X_b=[]
        b1x.grid(True)
        fig_bif_1_x.show()

    def _bifurcacion_2(self):
        global x0,y0,t_min,t_max,t_n,f,g
        global text_var_min_1,text_var_max_1,text_var_n_1,text_var_1
        global text_var_min_2,text_var_max_2,text_var_n_2,text_var_2
        self.OK()
        var_a=text_var_1.get()
        var_b=text_var_2.get()
        var_min_1=text_var_min_1.get()
        var_max_1=text_var_max_1.get()
        var_n_1=text_var_n_1.get()
        var_min_2=text_var_min_2.get()
        var_max_2=text_var_max_2.get()
        var_n_2=text_var_n_2.get()
        v_a=np.linspace(var_min_1,var_max_1,var_n_1)
        v_b=np.linspace(var_min_2,var_max_2,var_n_2)
        F_C,G_C=[],[]
        X_b,Y_b=[],[]
        X_b.append(x0)
        Y_b.append(y0)
        fig_bif_2_x=plt.figure()
        b2x=fig_bif_2_x.add_subplot(111)
        b2x.set_xlim([int(var_min)-1,int(var_max)+1])
        b2x.set_xlabel(var_name)
        b2x.set_ylabel('x')
        fig_bif_2_y=plt.figure()
        b2y=fig_bif_2_y.add_subplot(111)
        b2y.set_xlim([int(var_min)-1,int(var_max)+1])
        b2y.set_xlabel(var_name)
        b2y.set_ylabel('y')
        for i in range(0,len(var_a)):
            for j in range(0,len(var_b)):
                f.replace(var_a,str(a[i]))
                g.replace(var_a,str(a[i]))
                f.replace(var_b,str(b[j]))
                g.replace(var_b,str(b[j]))
                X_b,Y_b=Me.RK4_2D(f,g,Me._f_2D,Me._g_2D,x0,y0,t0,t_max,t_n)
                X_b_e=X_b[-100:]
                Y_b_e=Y_b[-100:]
                for x in X_b:
                    F_C.append(eval(f))
                    G_C.append(eval(g))
                val_f=np.sum(F_C)
                val_g=np.sum(G_C)
                if abs(val_f)<0.1:
                    b2x.plot(var_a,var_b)
                if abs(val_g)<0.1:
                    b2y.plot(var_a,var_b)
        b2x.grid(True)
        b2x.show()
        

                
    def _mx(self,x):
        m=texto_mx.get()
        return eval(m)
    def _my(self,y):
        m=texto_my.get()
        return eval(m)
    def _mxy(self,x,y):
        m=texto_mx.get()
        return eval(m)
    def _nxy(self,x,y):
        n=texto_my.get()
        return eval(n)

